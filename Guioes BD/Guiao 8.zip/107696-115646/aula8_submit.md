# BD: Guião 8


## ​8.1. Complete a seguinte tabela.
Complete the following table.

| #   | Query                                                                                                  | Rows  | Cost  | Pag. Reads | Time (ms) | Index used               | Index Op.            | Discussion |
| :-- | :--------------------------------------------------------------------------------------------------------- | :---- | :---- | :--------- | :-------- | :----------------------- | :------------------- | :--------- |
| 1   | SELECT \* from Production.WorkOrder                                                                        | 72591 | 0.484 | 531        | 1171      | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 2   | SELECT \* from Production.WorkOrder where WorkOrderID=1234                                                 | 1     | 0.000 | 28         | 35        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 3.1 | SELECT \* FROM Production.WorkOrder WHERE WorkOrderID between 10000 and 10010                              | 11    | 0.000 | 286        | 68        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 3.2 | SELECT \* FROM Production.WorkOrder WHERE WorkOrderID between 1 and 72591                                  | 72591 | 0.080 | 575        | 776       | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 4   | SELECT \* FROM Production.WorkOrder WHERE StartDate = '2007-06-25'                                         | 0     | 0.080 | 1724       | 121       | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 5   | SELECT \* FROM Production.WorkOrder WHERE ProductID = 757                                                  | 9     | 0.000 | 48         | 200       | IX_WorkOrder_ProductID   | Index Seek           |            |
| 6.1 | SELECT WorkOrderID, StartDate FROM Production.WorkOrder WHERE ProductID = 757                              | 9     | 0.000 | 64         | 86        | IX_WorkOrder_ProductID   | Index Seek           |            |
| 6.2 | SELECT WorkOrderID, StartDate FROM Production.WorkOrder WHERE ProductID = 945                              | 1105  | 0.000 | 556        | 54        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 6.3 | SELECT WorkOrderID FROM Production.WorkOrder WHERE ProductID = 945 AND StartDate = '2012-05-09'            | 1     | 0.001 | 558        | 16        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 7   | SELECT WorkOrderID, StartDate FROM Production.WorkOrder WHERE ProductID = 945 AND StartDate = '2012-05-09' | 1     | 0.008 | 558        | 79        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |
| 8   | SELECT WorkOrderID, StartDate FROM Production.WorkOrder WHERE ProductID = 945 AND StartDate = '2012-05-09' | 1     | 0.000 | 558        | 78        | PK_WorkOrder_WorkOrderID | Clustered Index Scan |            |

## ​8.2.

### a)

CREATE UNIQUE CLUSTERED INDEX rid_index ON dbo.mytemp(rid)
### b)


### c)

Fillfactor 65
		Inserted      50000 total records
Milliseconds used: 140080

Fillfactor 80
		Inserted      50000 total records
Milliseconds used: 138410

Fillfactor 90
		Inserted      50000 total records
Milliseconds used: 163433

### d)
d.	CREATE NONCLUSTERED INDEX at1_index ON mytemp(at1);
CREATE NONCLUSTERED INDEX at2_index ON mytemp(at2);
CREATE NONCLUSTERED INDEX at3_index ON mytemp(at3);
CREATE NONCLUSTERED INDEX lixo_index ON mytemp(lixo);

Sem indexes
Inserted      50000 total records
Milliseconds used: 249760

Com indexes
Inserted      50000 total records
Milliseconds used: 304643

### e)

CREATE INDEX IX_mytemp_at1 ON mytemp(at1);
CREATE INDEX IX_mytemp_at2 ON mytemp(at2);
CREATE INDEX IX_mytemp_at3 ON mytemp(at3);

Os tempos de execução aumentam uma vez que a operação está a ser efetuada para cada indice criado
## ​8.3.
3.	
  	 
--i.)CREATE UNIQUE CLUSTERED INDEX index_ssn ON Company.Employee(Ssn);

-- ii.)	CREATE NONCLUSTERED INDEX index_full_name ON Company.Employee(Fname, Lname);

--iii.)	CREATE NONCLUSTERED INDEX index_emp_dep ON Company.Employee(Dno);
CREATE UNIQUE CLUSTERED INDEX index_dep ON Company.Department(Dnumber);

--iv.)	CREATE UNIQUE CLUSTERED INDEX index_works ON Company.Works_on(Essn, Pno);
CREATE UNIQUE CLUSTERED INDEX index_ssn ON Company.Employee(Ssn);
CREATE NONCLUSTERED INDEX index_proj_no ON Company.Project(Pnumber);


