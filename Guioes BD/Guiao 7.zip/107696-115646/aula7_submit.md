# BD: Guião 7


## ​7.2 
 
### *a)*

```
... Write here your answer ...
It is possible to <u>underline</u> -> {A, B,.. }
-> R1 (_A_, B, C)
-> R2 (B,F)
A relação apresentada está na 1ª Forma Normal, porque a relação apenas apresenta atributos atómicos e não contém relações dentro de relações

### *b)* 

Para a 2ª Forma Normal, existe dependência entre Nome_Autor (Chave) e Afiliação_Autor. Separa-se numa nova tabela L2 (Nome_Autor, Afiliação_Autor).




## ​7.3
 
### *a)*
a.	A chave de R é { A; B }. Todos os elementos dependem destes atributos e estes não dependem de nenhum.

### *b)* 

```
... Write here your answer ...
```


### *c)* 

```
... Write here your answer ...
```


## ​7.4
 
### *a)*

A chave de R é { A; B }

### *b)* 

```
... Write here your answer ...
```


### *c)* 

```
... Write here your answer ...
```



## ​7.5
 
### *a)*

A chave de R é { A; B }.

### *b)* 

```
... Write here your answer ...
```


### *c)* 

```
... Write here your answer ...
```

### *d)* 

```
... Write here your answer ...
```
