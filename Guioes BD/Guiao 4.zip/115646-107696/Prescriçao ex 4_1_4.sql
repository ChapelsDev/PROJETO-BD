CREATE TABLE MEDICO(
	nr_sns INT NOT NULL,
	nome VARCHAR(50) NOT NULL,
	especialidade VARCHAR(50),
	PRIMARY KEY(nr_sns)
);
CREATE TABLE PACIENTE(
	num_utente INT NOT NULL ,
	data_Nasc DATE NOT NULL,
	nome VARCHAR(50) NOT NULL,
	endereco VARCHAR(50) NOT NULL,
	PRIMARY KEY(num_utente)
);

CREATE TABLE FARMACIA(
	nif INT NOT NULL,
	endereco VARCHAR(50) NOT NULL ,
	nome VARCHAR(50) NOT NULL ,
	telefone INT NOT NULL
	PRIMARY KEY(NIF)
);

CREATE TABLE FARMACEUTICA(
	nr_registo INT NOT NULL ,
	nome VARCHAR(50) NOT NULL,
	telefone INT NOT NULL ,
	endereco VARCHAR(50) NOT NULL
	PRIMARY KEY(nr_registo)
); 
CREATE TABLE PRESCRICAO(
	nr_unico INT NOT NULL,
	dat INT NOT NULL,
	medico_nr_sns INT NOT NULL,
	paciente_num_utente INT NOT NULL,
	farmacia_nif INT NOT NULL,
	PRIMARY KEY(nr_unico),
	FOREIGN KEY(medico_nr_sns) REFERENCES MEDICO(nr_sns),
	FOREIGN KEY(paciente_num_utente) REFERENCES paciente(num_utente),
	FOREIGN KEY(farmacia_nif) REFERENCES FARMACIA(nif),
);

CREATE TABLE FARMACO(
	farma_nr_registo INT NOT NULL ,
	nome VARCHAR(50) NOT NULL ,
	formula VARCHAR(50) NOT NULL ,
	PRIMARY KEY(farma_nr_registo , nome),
	FOREIGN KEY(farma_nr_registo) REFERENCES FARMACEUTICA(nr_registo),
);

CREATE TABLE TEM(
	farmaco_nome VARCHAR(50) ,
	presc_nr_unico INT NOT NULL ,
	farmac_nr_registo INT NOT NULL ,
	PRIMARY KEY(presc_nr_unico , farmaco_nome),
	FOREIGN KEY(farmac_nr_registo , farmaco_nome) REFERENCES FARMACO(farma_nr_registo , nome),
	FOREIGN KEY(presc_nr_unico) REFERENCES PRESCRICAO(nr_unico)
);