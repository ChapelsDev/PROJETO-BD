CREATE TABLE PESSOA(
	nr_cartao INT NOT NULL,
	morada VARCHAR(50) NOT NULL ,
	data_nasci DATE NOT NULL,
	nome VARCHAR(50) NOT NULL ,
	PRIMARY KEY(nr_cartao)
);
CREATE TABLE TURMA(
	identificador VARCHAR(50) NOT NULL,
	designacao VARCHAR(50) NOT NULL ,
	ano_lect INT NOT NULL,
	nr_maximo_alun INT NOT NULL,
	PRIMARY KEY(identificador)
);
CREATE TABLE ALUNO(
    nr_cartao INT NOT NULL,
    morada VARCHAR(50) NOT NULL ,
    data_nasci DATE NOT NULL,
    nome VARCHAR(50) NOT NULL,
    PRIMARY KEY(nr_cartao),
    FOREIGN KEY(nr_cartao) REFERENCES PESSOA(nr_cartao)
);

CREATE TABLE ENCARREGADO(
	nr_cc_edu INT NOT NULL,
	email VARCHAR(50) NOT NULL ,  
	contancto INT NOT NULL,
	autorizado BIT NOT NULL ,
	PRIMARY KEY(nr_cc_edu , email),
	FOREIGN KEY(nr_cc_edu) REFERENCES ALUNO(nr_cartao)
);
CREATE TABLE PROFESSOR(
	nr_cartao INT NOT NULL,
	email VARCHAR(50) NOT NULL ,
	nr_funci INT NOT NULL,
	turma_identificador VARCHAR(50) NOT NULL,
	contancto INT NOT NULL,
	morada VARCHAR(50) NOT NULL ,
	data_nasci DATE NOT NULL,
	nome VARCHAR(50) NOT NULL,
	PRIMARY KEY(nr_cartao),
	FOREIGN KEY(nr_cartao) REFERENCES PESSOA(nr_cartao),
	FOREIGN KEY(turma_identificador) REFERENCES TURMA(identificador),
);

CREATE TABLE ACTIVIDADE(
	identificador VARCHAR(50) NOT NULL,
	custo INT NOT NULL,
	designacao VARCHAR(50) NOT NULL,
	PRIMARY KEY(identificador)
);

CREATE TABLE TEM_d(
	actividade_identificador VARCHAR(50) NOT NULL,
	turma_identificador VARCHAR(50) NOT NULL ,
	PRIMARY KEY(turma_identificador,actividade_identificador),
	FOREIGN KEY(turma_identificador) REFERENCES TURMA(identificador),
	FOREIGN KEY(actividade_identificador) REFERENCES ACTIVIDADE(identificador)
);

CREATE TABLE FREQUENTA(
	turma_identificador VARCHAR(50) NOT NULL,
	nr_cartao INT NOT NULL,
	actividade_identificador VARCHAR(50) NOT NULL,
	PRIMARY KEY(actividade_identificador,nr_cartao),
	FOREIGN KEY(actividade_identificador) REFERENCES ACTIVIDADE(identificador),
	FOREIGN KEY(nr_cartao) REFERENCES ALUNO(nr_cartao),
	FOREIGN KEY(turma_identificador) REFERENCES Turma(identificador),
);
