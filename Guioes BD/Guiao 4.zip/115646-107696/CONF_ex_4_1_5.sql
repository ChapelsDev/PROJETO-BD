CREATE TABLE CONFERENCIA(
	id INT NOT NULL,
	PRIMARY KEY(id)
);
CREATE TABLE INSTITUICAO(
	nome varchar(50) NOT NULL ,
	endereco varchar(50) NOT NULL ,
	PRIMARY KEY(nome)
);
CREATE TABLE ARTIGO(
	nr_registo INT NOT NULL ,
	titulo varchar(50) NOT NULL ,
	PRIMARY KEY(nr_registo)
);
CREATE TABLE APRESENTA(
	Id_confe INT NOT NULL ,
	nr_registo_artigo INT NOT NULL,
	PRIMARY KEY(id_confe , nr_registo_artigo),
	FOREIGN KEY(id_confe) REFERENCES CONFERENCIA(id),
	FOREIGN KEY(nr_registo_artigo) REFERENCES ARTIGO(nr_registo),
);
CREATE TABLE AUTOR (
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    inst_nom VARCHAR(50) NOT NULL,
    PRIMARY KEY (email),
    FOREIGN KEY (inst_nom) REFERENCES INSTITUICAO (nome)
);

CREATE TABLE TEM_A(
	email_autor varchar(50) NOT NULL ,
	nr_registo_artigo INT NOT NULL,
	PRIMARY KEY(email_autor , nr_registo_artigo),
	FOREIGN KEY(email_autor) REFERENCES AUTOR(email),
	FOREIGN KEY(nr_registo_artigo) REFERENCES ARTIGO(nr_registo),
);
CREATE TABLE PARTICIPANTE(
	email varchar(50) NOT NULL,
	data_insc DATE NOT NULL,
	morada varchar(50) NOT NULL,
	nome varchar(50) NOT NULL ,
	id_confe INT NOT NULL ,
	PRIMARY KEY(email),
	FOREIGN KEY(id_confe) REFERENCES CONFERENCIA(id),
);
CREATE TABLE NAO_ESTUDANTE(
	email varchar(50) NOT NULL ,
	data_insc DATE NOT NULL,
	morada varchar(50) NOT NULL,
	nome varchar(50) NOT NULL ,
	refe_trans INT NOT NULL,
	PRIMARY KEY(email),
	FOREIGN KEY(email) REFERENCES PARTICIPANTE(email),
);
CREATE TABLE ESTUDANTE(
	email varchar(50) NOT NULL ,
	data_insc DATE NOT NULL,
	morada varchar(50) NOT NULL,
	nome varchar(50) NOT NULL ,
	inst_nom varchar(50) NOT NULL ,
	PRIMARY KEY(email),
	FOREIGN KEY(email) REFERENCES PARTICIPANTE(email),
	FOREIGN KEY(inst_nom) REFERENCES INSTITUICAO(nome),
);