# BD: Guião 3


## ​Problema 3.1
 
### *a)*

```
Cliente: cliente(nome, endereço, num_carta, NIF)
Aluguer: aluguer(número, duração, data)
Balcão: balcao(nome, número, endereço)
Veículo: veiculo(matrícula, marca, ano)
Tipo_veículo: tipo_veiculo(designação, ar_condicionado, código)
Similaridade: similaridade(codigo_a, codigo_b)
Pesado: pesado(peso, passageiros)
Ligeiro: ligeiro(numlugares, portas, combustivel)

```


### *b)* 

```
Chaves candidatas:

Cliente: num_carta,NIF
Aluguer: número(Cliente_NIF + Cliente_num_carta + Veiculo_matricula + Balcao_número)
Balcão: número
Veiculo: matricula
Tipo_veiculo: codigo
Similaridade: codigo_a,codigo_b
Pesado: codigo
Ligeiro: codigo

Chave principal:

Cliente: NIF
Aluguer: número
Balcão: número
Veiculo: matricula
Tipo_veiculo: codigo
Similaridade: codigo_a,codigo_b
Pesado: codigo
Ligeiro: codigo

Chaves estrangeiras:

Cliente: não tem
Aluguer: Titular, Local, Objeto
Balcão: não tem
Veiculo: Tipo
Tipo_veiculo: não tem
Similaridade: codigo_a,codigo_b
Pesado: codigo
Ligeiro: codigo

```


### *c)* 

![ex_3_1c!](ex_3_1c.jpg "AnImage")


## ​Problema 3.2

### *a)*

```
Airport: airport(Airport_Code, City, State, Name)
Airplane_Type: airplane_type(Type_Name, Max_Seats, Company)
Airplane: airplane(Airplane_Id, Total_No_Of_Seats, Airplane_Type)
Flight_Leg: flight_leg(Leg_no, Flight_number, Airpor_Code_Dep, Airport_Code_Arr, Sch_Dep_Time, Sch_Arr_Time)
Flight: flight(Number, Airline, Weekdays)
Fare: fare(Code, Amount, Restrictions, Flight_Number)
Leg_Instance: leg_instance(Date, No_Of_Avail_Seats, Flight_Number, Airport_Code_Dep, Airport_Code_Arr, Dep_Time, Arr_Time, Airplane)
Seat: seat(Date, Seat_No, Flight_Number, Leg_Number, Costumer_Name, Phone)
Can_Land: can_land(Airplane_Type, Airport)

```


### *b)* 

```
Chave parcial: Quando uma chave surge a tracejado no Diagrama

Chaves candidatas:

Airport: Airport_Code,Name
Airplane_Type: Type_Name
Airplane: Airplane_id
Flight_Leg: Leg_No
Flight: Number
Fare: Code
Leg_instance: Date
Can_Land: Airport_code,type_name
Seat: Seat_no,costumer_name

Chaves principal:

Airport: Airport_Code
Airplane_Type: Type_Name
Airplane: Airplane_id
Flight_Leg: Leg_No
Flight: Number
Fare: Code
Leg_instance: Flight_Number,Leg_No,Date
Can_Land:Airport_code,type_name
Seat: Seat_No

Chaves estrangeiras:

Airport: não tem
Airplane_Type: não tem
Airplane: Airplane_type
Flight_Leg: Flight_Number,Leg_Number,cod_airport_arr, cod_airport_dep
Flight: não tem
Fare: Flight_Number
Leg_instance: Flight_Number,Leg_No,Airport_Code_Dep,Airport_Code_Arr,Date,Airplane_id
Can_Land: Airport_code, type_name
Seat: Flight_Number,Leg_Number,Date,Flight_Number


```


### *c)* 

![ex_3_2c!](ex_3_2c.jpg "AnImage")


## ​Problema 3.3


### *a)* 2.1

![ex_3_3_a!](ex_3_3a.jpg "AnImage")

### *b)* 2.2

![ex_3_3_b!](ex_3_3b.jpg "AnImage")

### *c)* 2.3

![ex_3_3_c!](ex_3_3c.jpg "AnImage")

### *d)* 2.4

![ex_3_3_d!](ex_3_3d.jpg "AnImage")