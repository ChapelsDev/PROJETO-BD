# BD: Guião 5


## ​Problema 5.1
 
### *a)*

```
π Fname, Lname, Ssn, Pname (employee ⨝ Ssn = Essn works_on ⨝ Pno = Pnumber project)
```


### *b)* 

```
π employee.Fname, employee.Lname ( σ Chefe.Fname = 'Carlos' and Chefe.Minit = 'D' and Chefe.Lname = 'Gomes' (employee ⨝ employee.Super_ssn = Chefe.Ssn ρ Chefe employee))
```


### *c)* 

```
γ Pname; SUM(Hours)→total_Hours (project ⨝ project.Pnumber = works_on.Pno works_on)

```


### *d)* 

```
π employee.Fname, employee.Lname ( σ employee.Dno = 3 and project.Pname = 'Aveiro Digital' and works_on.Hours > 20 (employee ⨝ employee.Ssn = works_on.Essn works_on ⨝ works_on.Pno = project.Pnumber project))
```


### *e)* 

```
π Fname, Lname σ Essn = null (employee ⟕ Ssn = Essn works_on)

```


### *f)* 

```
π Fname, Lname, Ssn, Pname (employee ⨝ Ssn = Essn works_on ⨝ Pno = Pnumber project)
```


### *g)* 

```
σ filhos > 2 γ Fname, Lname; COUNT(Essn)→filhos (employee ⨝ Essn = Ssn dependent)
```


### *h)* 

```
... NODEP_EMP = σEssn= null (dependent ⟖Essn=Ssn employee)
π Fname,Minit,Lname (department ⨝Mgr_ssn=Ssn NODEP_EMP)
```


### *i)* 

```
... PROJECT_LST = σDlocation!='Aveiro'∧Plocation='Aveiro' (project ⨝Dnum=Dnumber dept_location)
π Fname,Minit,Lname,Address (employee ⨝Dno=Dnum PROJECT_LST)
```


## ​Problema 5.2

### *a)*

```
... π nome (σ fornecedor=null (encomenda ⟗fornecedor=nif fornecedor))
```

### *b)* 

```
... π nome, media (γ codProd;avg(unidades)-> media (item) ⨝codProd=codigo produto)
```


### *c)* 

```
... γ;avg(num_prod)->media (γ numEnc;count(codProd)-> num_prod (item))
```


### *d)* 

```
... AUX_TABLE = γ codProd,fornecedor;sum(unidades)->qnt_total (item ⨝numEnc=numero encomenda)
π fornecedor.nome,produto.nome,qnt_total (AUX_TABLE ⨝fornecedor=nif fornecedor ⨝codProd=codigo produto)
```


## ​Problema 5.3

### *a)*

```
... πnome,paciente.numUtente (σ numPresc=null (prescricao ⟗prescricao.numUtente=paciente.numUtente paciente))
```

### *b)* 

```
...γespecialidade;count(numPresc)->total_presc (prescricao ⨝numMedico=numSNS medico) 
```


### *c)* 

```
... γ nome; count(numPresc)->total_presc (prescricao ⨝farmacia=nome farmacia)
```


### *d)* 

```
... FARMACO_906 = πfarmaco.nome (σ numRegFarm=906 (farmaco ⨝numRegFarm=numReg farmaceutica))
PRESC_906 = πnomeFarmaco (σ numRegFarm=906 presc_farmaco)
FARMACO_906 - PRESC_906
```

### *e)* 

```
... FARM_SELLED = σfarmacia!=null (presc_farmaco ⨝presc_farmaco.numPresc=prescricao.numPresc prescricao)
AUX_TABLE = γ farmacia, numRegFarm; count(numRegFarm)->qtd_farmacos FARM_SELLED
πfarmacia,nome,qtd_farmacos (AUX_TABLE ⨝numRegFarm=numReg farmaceutica)
```

### *f)* 

```
... UTENTE_2MED = σ medicos_dif>1 (γ numUtente; count(numMedico)->medicos_dif (π numUtente,numMedico prescricao))
πnome (paciente ⨝paciente.numUtente=prescricao.numUtente UTENTE_2MED)
```
